#!/usr/bin/env python3
"""
Test form and JSON target enumeration
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from modules.targets import enumerate_targets

def test_form_json_targets():
    print("🧪 Testing form and JSON target enumeration...")
    
    # Test cases for different parameter locations
    test_cases = [
        {
            "name": "Query parameters only",
            "endpoint": {
                "url": "http://localhost:5001/search?q=test&page=1",
                "path": "/search",
                "method": "GET",
                "param_locs": {
                    "query": ["q", "page"],
                    "form": [],
                    "json": []
                },
                "status": 200,
                "content_type": "text/html"
            },
            "expected_targets": [
                {"param": "q", "param_in": "query"},
                {"param": "page", "param_in": "query"}
            ]
        },
        {
            "name": "Form parameters only",
            "endpoint": {
                "url": "http://localhost:5001/login",
                "path": "/login",
                "method": "POST",
                "param_locs": {
                    "query": [],
                    "form": ["username", "password"],
                    "json": []
                },
                "status": 200,
                "content_type": "text/html"
            },
            "expected_targets": [
                {"param": "username", "param_in": "form"},
                {"param": "password", "param_in": "form"}
            ]
        },
        {
            "name": "JSON parameters only",
            "endpoint": {
                "url": "http://localhost:5001/api/search-json",
                "path": "/api/search-json",
                "method": "POST",
                "param_locs": {
                    "query": [],
                    "form": [],
                    "json": ["query", "limit", "offset"]
                },
                "status": 200,
                "content_type": "application/json"
            },
            "expected_targets": [
                {"param": "query", "param_in": "json"},
                {"param": "limit", "param_in": "json"},
                {"param": "offset", "param_in": "json"}
            ]
        },
        {
            "name": "Mixed parameters (query + form)",
            "endpoint": {
                "url": "http://localhost:5001/submit?token=abc123",
                "path": "/submit",
                "method": "POST",
                "param_locs": {
                    "query": ["token"],
                    "form": ["name", "email"],
                    "json": []
                },
                "status": 200,
                "content_type": "text/html"
            },
            "expected_targets": [
                {"param": "token", "param_in": "query"},
                {"param": "name", "param_in": "form"},
                {"param": "email", "param_in": "form"}
            ]
        },
        {
            "name": "All parameter types",
            "endpoint": {
                "url": "http://localhost:5001/api/complex?filter=active",
                "path": "/api/complex",
                "method": "POST",
                "param_locs": {
                    "query": ["filter"],
                    "form": ["title", "description"],
                    "json": ["data", "metadata"]
                },
                "status": 200,
                "content_type": "application/json"
            },
            "expected_targets": [
                {"param": "filter", "param_in": "query"},
                {"param": "title", "param_in": "form"},
                {"param": "description", "param_in": "form"},
                {"param": "data", "param_in": "json"},
                {"param": "metadata", "param_in": "json"}
            ]
        },
        {
            "name": "No parameters",
            "endpoint": {
                "url": "http://localhost:5001/notes",
                "path": "/notes",
                "method": "GET",
                "param_locs": {
                    "query": [],
                    "form": [],
                    "json": []
                },
                "status": 200,
                "content_type": "text/html"
            },
            "expected_targets": []
        }
    ]
    
    # Run tests
    passed = 0
    total = 0
    
    for test_case in test_cases:
        name = test_case["name"]
        endpoint = test_case["endpoint"]
        expected_targets = test_case["expected_targets"]
        
        print(f"\n📋 Testing: {name}")
        print(f"   Endpoint: {endpoint['method']} {endpoint['path']}")
        print(f"   Param locations: {endpoint['param_locs']}")
        print(f"   Expected targets: {len(expected_targets)}")
        
        try:
            targets = enumerate_targets(endpoint)
            print(f"   Actual targets: {len(targets)}")
            
            # Check if we got the right number of targets
            if len(targets) != len(expected_targets):
                print(f"   ❌ FAIL - Expected {len(expected_targets)} targets, got {len(targets)}")
                total += 1
                continue
            
            # Check each target
            target_matches = []
            for i, target in enumerate(targets):
                expected = expected_targets[i]
                actual = {"param": target.param, "param_in": target.param_in}
                
                if actual == expected:
                    target_matches.append(True)
                    print(f"     ✅ {target.param} ({target.param_in})")
                else:
                    target_matches.append(False)
                    print(f"     ❌ Expected {expected}, got {actual}")
            
            if all(target_matches):
                print(f"   ✅ PASS - All targets match expectations")
                passed += 1
            else:
                print(f"   ❌ FAIL - Target mismatches")
            
            total += 1
            
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            total += 1
    
    print(f"\n🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✅ All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = test_form_json_targets()
    sys.exit(0 if success else 1)
