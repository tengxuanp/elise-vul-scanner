#!/usr/bin/env python3
"""
Test the probe engine with various targets
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from modules.probes.engine import run_probes, ProbeResult
from modules.targets import Target

def test_probe_engine():
    print("🧪 Testing probe engine with various targets...")
    
    # Test cases based on acceptance criteria
    test_cases = [
        {
            "name": "Search endpoint - should detect HTML XSS context",
            "target": Target(
                url="http://localhost:5001/search?q=test",
                path="/search",
                method="GET",
                param="q",
                param_in="query",
                status=200,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "html",
            "expected_redirect": False,
            "expected_sqli": False
        },
        {
            "name": "Profile endpoint - should detect attribute XSS context",
            "target": Target(
                url="http://localhost:5001/profile?name=test",
                path="/profile",
                method="GET",
                param="name",
                param_in="query",
                status=200,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "attr",
            "expected_redirect": False,
            "expected_sqli": False
        },
        {
            "name": "Script endpoint - should detect JS string XSS context",
            "target": Target(
                url="http://localhost:5001/script?msg=test",
                path="/script",
                method="GET",
                param="msg",
                param_in="query",
                status=200,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "js_string",
            "expected_redirect": False,
            "expected_sqli": False
        },
        {
            "name": "Product endpoint - should detect both XSS and SQLi",
            "target": Target(
                url="http://localhost:5001/product?id=1",
                path="/product",
                method="GET",
                param="id",
                param_in="query",
                status=200,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "html",  # Product endpoint also reflects in HTML
            "expected_redirect": False,
            "expected_sqli": True
        },
        {
            "name": "Redirect endpoint - should detect redirect influence",
            "target": Target(
                url="http://localhost:5001/go?url=test",
                path="/go",
                method="GET",
                param="url",
                param_in="query",
                status=302,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "none",
            "expected_redirect": True,
            "expected_sqli": False
        },
        {
            "name": "Notes endpoint - should not detect anything",
            "target": Target(
                url="http://localhost:5001/notes",
                path="/notes",
                method="GET",
                param="",
                param_in="query",
                status=200,
                content_type="text/html",
                provenance_ids=[1]
            ),
            "expected_xss": "none",
            "expected_redirect": False,
            "expected_sqli": False
        }
    ]
    
    # Run tests
    passed = 0
    total = 0
    
    for test_case in test_cases:
        name = test_case["name"]
        target = test_case["target"]
        expected_xss = test_case["expected_xss"]
        expected_redirect = test_case["expected_redirect"]
        expected_sqli = test_case["expected_sqli"]
        
        print(f"\n📋 Testing: {name}")
        print(f"   Target: {target.method} {target.path}?{target.param}=<value>")
        print(f"   Expected: XSS={expected_xss}, Redirect={expected_redirect}, SQLi={expected_sqli}")
        
        try:
            result = run_probes(target)
            print(f"   Result:")
            print(f"     XSS context: {result.xss_context}")
            print(f"     Redirect influence: {result.redirect_influence}")
            print(f"     SQLi error-based: {result.sqli_error_based} (db: {result.sqli_error_db})")
            print(f"     SQLi boolean delta: {result.sqli_boolean_delta:.3f}")
            print(f"     SQLi time-based: {result.sqli_time_based}")
            
            # Check if results match expectations
            xss_match = result.xss_context == expected_xss
            redirect_match = result.redirect_influence == expected_redirect
            sqli_match = (result.sqli_error_based or result.sqli_boolean_delta > 0.08 or result.sqli_time_based) == expected_sqli
            
            if xss_match and redirect_match and sqli_match:
                print(f"   ✅ PASS - All results match expectations")
                passed += 1
            else:
                print(f"   ❌ FAIL - Mismatches:")
                if not xss_match:
                    print(f"     XSS: expected {expected_xss}, got {result.xss_context}")
                if not redirect_match:
                    print(f"     Redirect: expected {expected_redirect}, got {result.redirect_influence}")
                if not sqli_match:
                    print(f"     SQLi: expected {expected_sqli}, got {(result.sqli_error_based or result.sqli_boolean_delta > 0.08 or result.sqli_time_based)}")
            
            total += 1
            
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            total += 1
    
    print(f"\n🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✅ All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = test_probe_engine()
    sys.exit(0 if success else 1)
