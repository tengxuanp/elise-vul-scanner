#!/usr/bin/env python3
"""
Test the SQLi triage probes
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from modules.probes.sqli_triage import triage

def test_sqli_triage():
    print("🧪 Testing SQLi triage probes...")
    
    # Test cases based on acceptance criteria
    test_cases = [
        {
            "name": "Product endpoint - should detect SQLi",
            "url": "http://localhost:5001/product",
            "method": "GET",
            "in_": "query",
            "param": "id",
            "expected_signals": ["error_based", "boolean_delta"]
        },
        {
            "name": "Search endpoint - should not detect SQLi",
            "url": "http://localhost:5001/search",
            "method": "GET",
            "in_": "query",
            "param": "q",
            "expected_signals": []
        },
        {
            "name": "Profile endpoint - should not detect SQLi",
            "url": "http://localhost:5001/profile",
            "method": "GET",
            "in_": "query",
            "param": "name",
            "expected_signals": []
        },
        {
            "name": "Script endpoint - should not detect SQLi",
            "url": "http://localhost:5001/script",
            "method": "GET",
            "in_": "query",
            "param": "msg",
            "expected_signals": []
        },
        {
            "name": "Non-existent endpoint - should not detect SQLi",
            "url": "http://localhost:5001/nonexistent",
            "method": "GET",
            "in_": "query",
            "param": "test",
            "expected_signals": []
        }
    ]
    
    # Run tests
    passed = 0
    total = 0
    
    for test_case in test_cases:
        name = test_case["name"]
        url = test_case["url"]
        method = test_case["method"]
        in_ = test_case["in_"]
        param = test_case["param"]
        expected_signals = test_case["expected_signals"]
        
        print(f"\n📋 Testing: {name}")
        print(f"   URL: {url}?{param}=<sqli-payload>")
        print(f"   Expected signals: {expected_signals}")
        
        try:
            result = triage(url, method, in_, param)
            print(f"   Result:")
            print(f"     error_based: {result.error_based} (db: {result.error_db})")
            print(f"     boolean_delta: {result.boolean_delta:.3f}")
            print(f"     time_based: {result.time_based} (delta: {result.time_delta_ms:.1f}ms)")
            
            # Check if the result matches expectations
            detected_signals = []
            if result.error_based:
                detected_signals.append("error_based")
            if result.boolean_delta > 0.1:
                detected_signals.append("boolean_delta")
            if result.time_based:
                detected_signals.append("time_based")
            
            print(f"     Detected signals: {detected_signals}")
            
            # Check if detected signals match expected signals
            if set(detected_signals) == set(expected_signals):
                print(f"   ✅ PASS - Signals match expectations")
                passed += 1
            else:
                print(f"   ❌ FAIL - Expected {expected_signals}, got {detected_signals}")
            
            total += 1
            
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            total += 1
    
    print(f"\n🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✅ All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = test_sqli_triage()
    sys.exit(0 if success else 1)
