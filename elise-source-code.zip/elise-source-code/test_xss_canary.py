#!/usr/bin/env python3
"""
Test the XSS canary reflection context classifier
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from modules.probes.xss_canary import classify_reflection

def test_canary_classifier():
    print("🧪 Testing XSS canary reflection context classifier...")
    
    # Test cases based on acceptance criteria
    test_cases = [
        {
            "name": "Search endpoint - should return 'html'",
            "url": "http://localhost:5001/search",
            "method": "GET",
            "in_": "query",
            "param": "q",
            "expected": "html"
        },
        {
            "name": "Profile endpoint - should return 'attr'",
            "url": "http://localhost:5001/profile",
            "method": "GET",
            "in_": "query",
            "param": "name",
            "expected": "attr"
        },
        {
            "name": "Script endpoint - should return 'js_string'",
            "url": "http://localhost:5001/script",
            "method": "GET",
            "in_": "query",
            "param": "msg",
            "expected": "js_string"
        },
        {
            "name": "Notes endpoint (no params) - should return 'none'",
            "url": "http://localhost:5001/notes",
            "method": "GET",
            "in_": "query",
            "param": "test",
            "expected": "none"
        },
        {
            "name": "Non-existent endpoint - should return 'none'",
            "url": "http://localhost:5001/nonexistent",
            "method": "GET",
            "in_": "query",
            "param": "test",
            "expected": "none"
        }
    ]
    
    # Run tests
    passed = 0
    total = 0
    
    for test_case in test_cases:
        name = test_case["name"]
        url = test_case["url"]
        method = test_case["method"]
        in_ = test_case["in_"]
        param = test_case["param"]
        expected = test_case["expected"]
        
        print(f"\n📋 Testing: {name}")
        print(f"   URL: {url}?{param}=<canary>")
        print(f"   Expected: {expected}")
        
        try:
            result = classify_reflection(url, method, in_, param)
            print(f"   Result: {result}")
            
            if result == expected:
                print(f"   ✅ PASS")
                passed += 1
            else:
                print(f"   ❌ FAIL - Expected {expected}, got {result}")
            
            total += 1
            
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            total += 1
    
    print(f"\n🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✅ All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = test_canary_classifier()
    sys.exit(0 if success else 1)
