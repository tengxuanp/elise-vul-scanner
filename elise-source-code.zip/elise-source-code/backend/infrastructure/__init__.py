# Infrastructure module for shared resources
