#!/usr/bin/env python3
"""
Test script to verify BrowserPool functionality
"""

import asyncio
import sys
import os

# Add backend to path
sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'backend'))

async def test_browser_pool():
    """Test the BrowserPool initialization and basic functionality"""
    try:
        from infrastructure.browser_pool import browser_pool
        
        print("🚀 Testing BrowserPool...")
        
        # Test initialization
        print("📋 Initializing browser pool...")
        await browser_pool.init()
        print(f"✅ Browser pool initialized: {browser_pool.is_initialized}")
        
        # Test getting a context
        print("📋 Getting browser context...")
        context = await browser_pool.get_context(enable_js=True)
        print("✅ Browser context created successfully")
        
        # Test creating a page
        print("📋 Creating page...")
        page = await context.new_page()
        print("✅ Page created successfully")
        
        # Test navigation
        print("📋 Testing navigation...")
        try:
            await page.goto("https://httpbin.org/get", timeout=10000)
            print("✅ Navigation successful")
            
            # Get page title
            title = await page.title()
            print(f"📄 Page title: {title}")
            
        except Exception as e:
            print(f"⚠️ Navigation failed: {e}")
        
        # Cleanup
        print("📋 Cleaning up...")
        await context.close()
        print("✅ Context closed")
        
        # Test shutdown
        print("📋 Shutting down browser pool...")
        await browser_pool.shutdown()
        print("✅ Browser pool shutdown complete")
        
        print("🎉 All tests passed!")
        
    except Exception as e:
        print(f"❌ Test failed: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    asyncio.run(test_browser_pool())
