#!/usr/bin/env python3
"""
Test the redirect influence oracle
"""

import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), 'backend'))

from modules.probes.redirect_oracle import proves_open_redirect

def test_redirect_oracle():
    print("🧪 Testing redirect influence oracle...")
    
    # Test cases based on acceptance criteria
    test_cases = [
        {
            "name": "Go endpoint - should prove open redirect",
            "url": "http://localhost:5001/go",
            "method": "GET",
            "param": "url",
            "expected_proves": True,
            "expected_status_range": (300, 400)
        },
        {
            "name": "Search endpoint - should not prove redirect",
            "url": "http://localhost:5001/search",
            "method": "GET",
            "param": "q",
            "expected_proves": False
        },
        {
            "name": "Profile endpoint - should not prove redirect",
            "url": "http://localhost:5001/profile",
            "method": "GET",
            "param": "name",
            "expected_proves": False
        },
        {
            "name": "Script endpoint - should not prove redirect",
            "url": "http://localhost:5001/script",
            "method": "GET",
            "param": "msg",
            "expected_proves": False
        },
        {
            "name": "Non-existent endpoint - should not prove redirect",
            "url": "http://localhost:5001/nonexistent",
            "method": "GET",
            "param": "test",
            "expected_proves": False
        }
    ]
    
    # Run tests
    passed = 0
    total = 0
    
    for test_case in test_cases:
        name = test_case["name"]
        url = test_case["url"]
        method = test_case["method"]
        param = test_case["param"]
        expected_proves = test_case["expected_proves"]
        expected_status_range = test_case.get("expected_status_range")
        
        print(f"\n📋 Testing: {name}")
        print(f"   URL: {url}?{param}=<evil-url>")
        print(f"   Expected proves redirect: {expected_proves}")
        
        try:
            proves, status, location = proves_open_redirect(url, method, param)
            print(f"   Result: proves={proves}, status={status}")
            if location:
                print(f"   Location: {location[:100]}{'...' if len(location) > 100 else ''}")
            else:
                print(f"   Location: None")
            
            # Check if the result matches expectations
            if proves == expected_proves:
                if expected_status_range and proves:
                    if expected_status_range[0] <= status < expected_status_range[1]:
                        print(f"   ✅ PASS - Status {status} in expected range {expected_status_range}")
                        passed += 1
                    else:
                        print(f"   ❌ FAIL - Status {status} not in expected range {expected_status_range}")
                else:
                    print(f"   ✅ PASS")
                    passed += 1
            else:
                print(f"   ❌ FAIL - Expected proves={expected_proves}, got proves={proves}")
            
            total += 1
            
        except Exception as e:
            print(f"   ❌ ERROR: {e}")
            total += 1
    
    print(f"\n🎯 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("✅ All tests passed!")
        return True
    else:
        print("❌ Some tests failed!")
        return False

if __name__ == "__main__":
    success = test_redirect_oracle()
    sys.exit(0 if success else 1)
